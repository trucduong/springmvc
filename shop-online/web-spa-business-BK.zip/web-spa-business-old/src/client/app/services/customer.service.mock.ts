import {CustomerGroup} from '../models/index';

export const CUSTOMER_GROUPS: CustomerGroup[] = [
  {id: 1, name: 'Group 1', note:''},
  {id: 2, name: 'Group 2', note:''},
  {id: 3, name: 'Group 3', note:''},
  {id: 4, name: 'Group 4', note:''},
];