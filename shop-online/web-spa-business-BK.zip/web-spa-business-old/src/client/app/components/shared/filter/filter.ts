import { Component, OnInit } from 'angular2/core';

@Component({
    selector: 'filter-cmp',
    templateUrl: 'app/components/shared/filter/filter.html'
})
export class FilterCmp implements OnInit {
    constructor() { }
    ngOnInit() { }
}
