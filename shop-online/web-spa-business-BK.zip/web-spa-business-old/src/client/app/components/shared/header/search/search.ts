import {Component} from 'angular2/core';

@Component({
  selector: 'header-search',
  templateUrl: 'app/components/shared/header/search/search.html',
  directives: []
})

export class HeaderSearch {
}
