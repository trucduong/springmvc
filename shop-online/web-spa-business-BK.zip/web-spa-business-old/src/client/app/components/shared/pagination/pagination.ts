import { Component, OnInit } from 'angular2/core';

@Component({
    selector: 'pagination-cmp',
    templateUrl: 'app/components/shared/pagination/pagination.html',
    styleUrls: ['app/components/shared/pagination/pagination.css']
})
export class PaginationCmp implements OnInit {
    constructor() { }
    ngOnInit() { }
}
