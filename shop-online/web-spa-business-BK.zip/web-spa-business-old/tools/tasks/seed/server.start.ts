import {serveSPA} from '../../utils';

export = serveSPA
