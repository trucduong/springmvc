import {serveDocs} from '../../utils';

export = serveDocs
