import {serveProd} from '../../utils';

export = serveProd
