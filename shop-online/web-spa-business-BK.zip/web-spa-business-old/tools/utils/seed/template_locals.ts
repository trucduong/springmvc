import * as CONFIG from '../../config';

// TODO: Add an interface to register more template locals.
export function templateLocals() {
  return CONFIG;
}
