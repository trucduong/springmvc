/// <reference path="modules/xhr2/index.d.ts" />
